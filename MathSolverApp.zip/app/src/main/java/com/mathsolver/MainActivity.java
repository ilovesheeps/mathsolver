package com.mathsolver;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.mathsolver.R;
import com.mathsolver.api.GeminiApiClient;
import com.mathsolver.models.MathSolution;
import com.mathsolver.utils.ImageUtils;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Actividad principal de la aplicación
 * Maneja la captura de imágenes y el procesamiento inicial
 * Optimizada para Android 4.2.2 (API 17)
 */
public class MainActivity extends ActionBarActivity {
    
    private static final String TAG = "MainActivity";
    
    // Códigos de solicitud
    private static final int REQUEST_CAMERA_PERMISSION = 1001;
    private static final int REQUEST_STORAGE_PERMISSION = 1002;
    private static final int REQUEST_IMAGE_CAPTURE = 2001;
    private static final int REQUEST_IMAGE_GALLERY = 2002;
    
    // Componentes de UI
    private Button btnCapturePhoto;
    private Button btnSelectGallery;
    private ImageView ivPreview;
    private LinearLayout layoutProcessing;
    private ProgressBar progressProcessing;
    private TextView tvProcessingMessage;
    
    // Variables de estado
    private String currentPhotoPath;
    private GeminiApiClient geminiClient;
    private boolean isProcessing = false;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        Log.d(TAG, "MainActivity creada");
        
        // Inicializar componentes
        initializeViews();
        initializeGeminiClient();
        setupClickListeners();
        
        // Verificar permisos iniciales
        checkAndRequestPermissions();
    }
    
    /**
     * Inicializa las vistas de la interfaz
     */
    private void initializeViews() {
        try {
            btnCapturePhoto = (Button) findViewById(R.id.btn_capture_photo);
            btnSelectGallery = (Button) findViewById(R.id.btn_select_gallery);
            ivPreview = (ImageView) findViewById(R.id.iv_preview);
            layoutProcessing = (LinearLayout) findViewById(R.id.layout_processing);
            progressProcessing = (ProgressBar) findViewById(R.id.progress_processing);
            tvProcessingMessage = (TextView) findViewById(R.id.tv_processing_message);
            
            // Estado inicial
            layoutProcessing.setVisibility(View.GONE);
            ivPreview.setVisibility(View.GONE);
            
            Log.d(TAG, "Vistas inicializadas correctamente");
            
        } catch (Exception e) {
            Log.e(TAG, "Error inicializando vistas", e);
            showErrorDialog("Error inicializando interfaz");
        }
    }
    
    /**
     * Inicializa el cliente de Gemini API
     */
    private void initializeGeminiClient() {
        try {
            geminiClient = new GeminiApiClient();
            Log.d(TAG, "Cliente Gemini inicializado");
        } catch (Exception e) {
            Log.e(TAG, "Error inicializando cliente Gemini", e);
            showErrorDialog("Error inicializando servicio de IA");
        }
    }
    
    /**
     * Configura los listeners de los botones
     */
    private void setupClickListeners() {
        btnCapturePhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onCapturePhotoClicked();
            }
        });
        
        btnSelectGallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onSelectGalleryClicked();
            }
        });
    }
    
    /**
     * Verifica y solicita los permisos necesarios
     */
    private void checkAndRequestPermissions() {
        // Verificar permiso de cámara
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) 
                != PackageManager.PERMISSION_GRANTED) {
            
            ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.CAMERA},
                REQUEST_CAMERA_PERMISSION);
        }
        
        // Verificar permiso de almacenamiento
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) 
                != PackageManager.PERMISSION_GRANTED) {
            
            ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                REQUEST_STORAGE_PERMISSION);
        }
    }
    
    /**
     * Maneja el click del botón de captura de foto
     */
    private void onCapturePhotoClicked() {
        if (isProcessing) {
            Toast.makeText(this, "Procesando imagen anterior, espera por favor", Toast.LENGTH_SHORT).show();
            return;
        }
        
        // Verificar permiso de cámara
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) 
                != PackageManager.PERMISSION_GRANTED) {
            
            ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.CAMERA},
                REQUEST_CAMERA_PERMISSION);
            return;
        }
        
        dispatchTakePictureIntent();
    }
    
    /**
     * Maneja el click del botón de selección de galería
     */
    private void onSelectGalleryClicked() {
        if (isProcessing) {
            Toast.makeText(this, "Procesando imagen anterior, espera por favor", Toast.LENGTH_SHORT).show();
            return;
        }
        
        // Verificar permiso de almacenamiento
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) 
                != PackageManager.PERMISSION_GRANTED) {
            
            ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                REQUEST_STORAGE_PERMISSION);
            return;
        }
        
        dispatchSelectPictureIntent();
    }
    
    /**
     * Lanza el intent de captura de imagen
     */
    private void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        
        // Verificar que hay una app de cámara disponible
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            
            // Crear archivo para guardar la imagen
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException e) {
                Log.e(TAG, "Error creando archivo de imagen", e);
                Toast.makeText(this, "Error creando archivo temporal", Toast.LENGTH_SHORT).show();
                return;
            }
            
            // Continuar si el archivo se creó exitosamente
            if (photoFile != null) {
                Uri photoURI = FileProvider.getUriForFile(this,
                    "com.mathsolver.fileprovider",
                    photoFile);
                
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
            }
        } else {
            Toast.makeText(this, "No hay aplicación de cámara disponible", Toast.LENGTH_SHORT).show();
        }
    }
    
    /**
     * Lanza el intent de selección de imagen de galería
     */
    private void dispatchSelectPictureIntent() {
        Intent selectPictureIntent = new Intent(Intent.ACTION_GET_CONTENT);
        selectPictureIntent.setType("image/*");
        
        if (selectPictureIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(selectPictureIntent, REQUEST_IMAGE_GALLERY);
        } else {
            Toast.makeText(this, "No hay aplicación de galería disponible", Toast.LENGTH_SHORT).show();
        }
    }
    
    /**
     * Crea un archivo temporal para la imagen capturada
     */
    private File createImageFile() throws IOException {
        // Crear nombre único para el archivo
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String imageFileName = "MATH_" + timeStamp + "_";
        
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
            imageFileName,  /* prefix */
            ".jpg",         /* suffix */
            storageDir      /* directory */
        );
        
        // Guardar ruta para uso posterior
        currentPhotoPath = image.getAbsolutePath();
        Log.d(TAG, "Archivo de imagen creado: " + currentPhotoPath);
        
        return image;
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        
        Log.d(TAG, "onActivityResult: requestCode=" + requestCode + ", resultCode=" + resultCode);
        
        if (resultCode != RESULT_OK) {
            Log.w(TAG, "Resultado de actividad no exitoso");
            return;
        }
        
        try {
            switch (requestCode) {
                case REQUEST_IMAGE_CAPTURE:
                    handleCapturedImage();
                    break;
                    
                case REQUEST_IMAGE_GALLERY:
                    handleSelectedImage(data);
                    break;
                    
                default:
                    Log.w(TAG, "Código de solicitud no reconocido: " + requestCode);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error manejando resultado de actividad", e);
            showErrorDialog("Error procesando imagen");
        }
    }
    
    /**
     * Maneja la imagen capturada con la cámara
     */
    private void handleCapturedImage() {
        if (currentPhotoPath == null) {
            Log.e(TAG, "Ruta de foto actual es null");
            showErrorDialog("Error: no se pudo guardar la imagen");
            return;
        }
        
        Log.d(TAG, "Procesando imagen capturada: " + currentPhotoPath);
        
        // Cargar y procesar la imagen
        Bitmap bitmap = ImageUtils.loadBitmapFromFile(currentPhotoPath, 1024);
        
        if (bitmap != null) {
            processImageWithAI(bitmap);
        } else {
            showErrorDialog("Error cargando la imagen capturada");
        }
    }
    
    /**
     * Maneja la imagen seleccionada de la galería
     */
    private void handleSelectedImage(Intent data) {
        if (data == null || data.getData() == null) {
            Log.e(TAG, "Datos de imagen de galería nulos");
            showErrorDialog("Error: no se pudo obtener la imagen seleccionada");
            return;
        }
        
        Uri imageUri = data.getData();
        Log.d(TAG, "Procesando imagen de galería: " + imageUri.toString());
        
        try {
            Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), imageUri);
            
            if (bitmap != null) {
                // Comprimir para dispositivos antiguos
                bitmap = ImageUtils.compressForOldDevices(bitmap, 1024);
                processImageWithAI(bitmap);
            } else {
                showErrorDialog("Error cargando la imagen seleccionada");
            }
        } catch (IOException e) {
            Log.e(TAG, "Error cargando imagen de galería", e);
            showErrorDialog("Error leyendo la imagen seleccionada");
        }
    }
    
    /**
     * Procesa la imagen con IA
     */
    private void processImageWithAI(final Bitmap bitmap) {
        if (bitmap == null || isProcessing) {
            return;
        }
        
        Log.d(TAG, "Iniciando procesamiento con IA");
        
        // Cambiar estado a procesando
        setProcessingState(true);
        
        // Mostrar vista previa
        ivPreview.setImageBitmap(bitmap);
        ivPreview.setVisibility(View.VISIBLE);
        
        // Procesar con Gemini API
        geminiClient.solveMathProblem(bitmap, new GeminiApiClient.MathSolutionCallback() {
            @Override
            public void onSuccess(final MathSolution solution) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        setProcessingState(false);
                        
                        Log.d(TAG, "Procesamiento exitoso");
                        
                        // Navegar a la pantalla de solución
                        Intent intent = new Intent(MainActivity.this, SolutionActivity.class);
                        intent.putExtra("solution", solution);
                        intent.putExtra("image_path", currentPhotoPath);
                        startActivity(intent);
                    }
                });
            }
            
            @Override
            public void onError(final String error) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        setProcessingState(false);
                        
                        Log.e(TAG, "Error en procesamiento: " + error);
                        showErrorDialog("Error procesando imagen: " + error);
                    }
                });
            }
            
            @Override
            public void onProgress(final String message) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        tvProcessingMessage.setText(message);
                        Log.d(TAG, "Progreso: " + message);
                    }
                });
            }
        });
    }
    
    /**
     * Cambia el estado de procesamiento de la UI
     */
    private void setProcessingState(boolean processing) {
        isProcessing = processing;
        
        if (processing) {
            layoutProcessing.setVisibility(View.VISIBLE);
            btnCapturePhoto.setEnabled(false);
            btnSelectGallery.setEnabled(false);
        } else {
            layoutProcessing.setVisibility(View.GONE);
            btnCapturePhoto.setEnabled(true);
            btnSelectGallery.setEnabled(true);
        }
    }
    
    /**
     * Muestra un diálogo de error
     */
    private void showErrorDialog(String message) {
        try {
            new AlertDialog.Builder(this)
                .setTitle("Error")
                .setMessage(message)
                .setPositiveButton("Aceptar", null)
                .show();
        } catch (Exception e) {
            Log.e(TAG, "Error mostrando diálogo", e);
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        }
    }
    
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        
        switch (requestCode) {
            case REQUEST_CAMERA_PERMISSION:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Log.d(TAG, "Permiso de cámara concedido");
                    Toast.makeText(this, "Permiso de cámara concedido", Toast.LENGTH_SHORT).show();
                } else {
                    Log.w(TAG, "Permiso de cámara denegado");
                    Toast.makeText(this, getString(R.string.camera_permission_required), Toast.LENGTH_LONG).show();
                }
                break;
                
            case REQUEST_STORAGE_PERMISSION:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Log.d(TAG, "Permiso de almacenamiento concedido");
                    Toast.makeText(this, "Permiso de almacenamiento concedido", Toast.LENGTH_SHORT).show();
                } else {
                    Log.w(TAG, "Permiso de almacenamiento denegado");
                    Toast.makeText(this, getString(R.string.storage_permission_required), Toast.LENGTH_LONG).show();
                }
                break;
        }
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        
        // Limpiar recursos
        if (ivPreview != null && ivPreview.getDrawable() != null) {
            ivPreview.setImageDrawable(null);
        }
        
        Log.d(TAG, "MainActivity destruida");
    }
}
