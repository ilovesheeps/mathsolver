package com.mathsolver.utils;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Utilidades para manejo optimizado de imágenes en Android 4.2.2
 * Enfocado en gestión eficiente de memoria para dispositivos de baja RAM
 */
public class ImageUtils {
    
    private static final String TAG = "ImageUtils";
    
    // Configuración para dispositivos de baja RAM
    private static final int DEFAULT_MAX_SIZE = 1024;
    private static final int JPEG_QUALITY = 85;
    private static final int SAMPLE_SIZE_THRESHOLD = 2048;
    
    /**
     * Comprime una imagen para dispositivos antiguos con limitaciones de memoria
     */
    public static Bitmap compressForOldDevices(Bitmap original, int maxSize) {
        if (original == null) {
            Log.e(TAG, "Bitmap original es null");
            return null;
        }
        
        try {
            int width = original.getWidth();
            int height = original.getHeight();
            
            Log.d(TAG, "Imagen original: " + width + "x" + height);
            
            // Si la imagen ya es pequeña, devolverla tal como está
            if (width <= maxSize && height <= maxSize) {
                Log.d(TAG, "Imagen ya es del tamaño correcto");
                return original;
            }
            
            // Calcular nuevo tamaño manteniendo proporción
            float ratio = Math.min(
                (float) maxSize / width,
                (float) maxSize / height
            );
            
            int newWidth = Math.round(width * ratio);
            int newHeight = Math.round(height * ratio);
            
            Log.d(TAG, "Redimensionando a: " + newWidth + "x" + newHeight);
            
            // Crear bitmap redimensionado con filtro para mejor calidad
            Bitmap resized = Bitmap.createScaledBitmap(original, newWidth, newHeight, true);
            
            // Liberar el bitmap original si no es el mismo objeto
            if (resized != original && !original.isRecycled()) {
                original.recycle();
            }
            
            return resized;
            
        } catch (OutOfMemoryError e) {
            Log.e(TAG, "OutOfMemoryError al comprimir imagen", e);
            
            // Intentar con tamaño más pequeño en caso de falta de memoria
            try {
                return compressForOldDevices(original, maxSize / 2);
            } catch (Exception e2) {
                Log.e(TAG, "Error en segundo intento de compresión", e2);
                return null;
            }
        } catch (Exception e) {
            Log.e(TAG, "Error comprimiendo imagen", e);
            return null;
        }
    }
    
    /**
     * Carga una imagen desde archivo con manejo eficiente de memoria
     */
    public static Bitmap loadBitmapFromFile(String filePath, int maxSize) {
        if (filePath == null || filePath.isEmpty()) {
            Log.e(TAG, "Ruta de archivo inválida");
            return null;
        }
        
        File file = new File(filePath);
        if (!file.exists()) {
            Log.e(TAG, "Archivo no existe: " + filePath);
            return null;
        }
        
        try {
            // Primero, obtener dimensiones sin cargar la imagen completa
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(filePath, options);
            
            int width = options.outWidth;
            int height = options.outHeight;
            
            Log.d(TAG, "Dimensiones del archivo: " + width + "x" + height);
            
            // Calcular sample size para reducir uso de memoria
            int sampleSize = calculateSampleSize(width, height, maxSize);
            
            // Configurar opciones para carga optimizada
            options.inJustDecodeBounds = false;
            options.inSampleSize = sampleSize;
            options.inPreferredConfig = Bitmap.Config.RGB_565; // Usa menos memoria que ARGB_8888
            options.inDither = false;
            options.inPurgeable = true; // Permite que el sistema libere memoria si es necesario
            options.inInputShareable = true;
            
            Log.d(TAG, "Cargando con sample size: " + sampleSize);
            
            Bitmap bitmap = BitmapFactory.decodeFile(filePath, options);
            
            if (bitmap == null) {
                Log.e(TAG, "No se pudo cargar el bitmap desde: " + filePath);
                return null;
            }
            
            // Verificar orientación y corregir si es necesario
            bitmap = correctImageOrientation(bitmap, filePath);
            
            // Redimensionar finalmente si es necesario
            if (bitmap.getWidth() > maxSize || bitmap.getHeight() > maxSize) {
                bitmap = compressForOldDevices(bitmap, maxSize);
            }
            
            return bitmap;
            
        } catch (OutOfMemoryError e) {
            Log.e(TAG, "OutOfMemoryError cargando imagen", e);
            
            // Intentar con sample size mayor
            try {
                BitmapFactory.Options fallbackOptions = new BitmapFactory.Options();
                fallbackOptions.inSampleSize = 4; // Reducir calidad drásticamente
                fallbackOptions.inPreferredConfig = Bitmap.Config.RGB_565;
                Bitmap fallbackBitmap = BitmapFactory.decodeFile(filePath, fallbackOptions);
                
                if (fallbackBitmap != null) {
                    return compressForOldDevices(fallbackBitmap, maxSize / 2);
                }
            } catch (Exception e2) {
                Log.e(TAG, "Error en carga fallback", e2);
            }
            
            return null;
        } catch (Exception e) {
            Log.e(TAG, "Error cargando bitmap desde archivo", e);
            return null;
        }
    }
    
    /**
     * Calcula el sample size óptimo para reducir uso de memoria
     */
    private static int calculateSampleSize(int width, int height, int maxSize) {
        int sampleSize = 1;
        
        if (height > maxSize || width > maxSize) {
            final int halfHeight = height / 2;
            final int halfWidth = width / 2;
            
            // Calcular sample size como potencia de 2
            while ((halfHeight / sampleSize) >= maxSize && (halfWidth / sampleSize) >= maxSize) {
                sampleSize *= 2;
            }
        }
        
        return sampleSize;
    }
    
    /**
     * Corrige la orientación de la imagen basándose en datos EXIF
     */
    private static Bitmap correctImageOrientation(Bitmap bitmap, String filePath) {
        if (bitmap == null || filePath == null) {
            return bitmap;
        }
        
        try {
            ExifInterface exif = new ExifInterface(filePath);
            int orientation = exif.getAttributeInt(
                ExifInterface.TAG_ORIENTATION, 
                ExifInterface.ORIENTATION_NORMAL
            );
            
            Matrix matrix = new Matrix();
            boolean needsRotation = false;
            
            switch (orientation) {
                case ExifInterface.ORIENTATION_ROTATE_90:
                    matrix.postRotate(90);
                    needsRotation = true;
                    break;
                case ExifInterface.ORIENTATION_ROTATE_180:
                    matrix.postRotate(180);
                    needsRotation = true;
                    break;
                case ExifInterface.ORIENTATION_ROTATE_270:
                    matrix.postRotate(270);
                    needsRotation = true;
                    break;
                case ExifInterface.ORIENTATION_FLIP_HORIZONTAL:
                    matrix.postScale(-1, 1);
                    needsRotation = true;
                    break;
                case ExifInterface.ORIENTATION_FLIP_VERTICAL:
                    matrix.postScale(1, -1);
                    needsRotation = true;
                    break;
            }
            
            if (needsRotation) {
                Log.d(TAG, "Corrigiendo orientación: " + orientation);
                
                Bitmap rotatedBitmap = Bitmap.createBitmap(
                    bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true
                );
                
                if (rotatedBitmap != bitmap && !bitmap.isRecycled()) {
                    bitmap.recycle();
                }
                
                return rotatedBitmap;
            }
            
        } catch (IOException e) {
            Log.e(TAG, "Error leyendo EXIF data", e);
        } catch (OutOfMemoryError e) {
            Log.e(TAG, "OutOfMemoryError al rotar imagen", e);
        } catch (Exception e) {
            Log.e(TAG, "Error corrigiendo orientación", e);
        }
        
        return bitmap;
    }
    
    /**
     * Guarda un bitmap a archivo con compresión optimizada
     */
    public static boolean saveBitmapToFile(Bitmap bitmap, String filePath, int quality) {
        if (bitmap == null || filePath == null) {
            Log.e(TAG, "Bitmap o ruta de archivo inválidos");
            return false;
        }
        
        try {
            File file = new File(filePath);
            File parentDir = file.getParentFile();
            
            if (parentDir != null && !parentDir.exists()) {
                if (!parentDir.mkdirs()) {
                    Log.e(TAG, "No se pudo crear directorio: " + parentDir.getAbsolutePath());
                    return false;
                }
            }
            
            FileOutputStream fos = new FileOutputStream(file);
            boolean success = bitmap.compress(Bitmap.CompressFormat.JPEG, quality, fos);
            
            fos.flush();
            fos.close();
            
            Log.d(TAG, "Imagen guardada: " + filePath + " (calidad: " + quality + ")");
            
            return success;
            
        } catch (IOException e) {
            Log.e(TAG, "Error guardando imagen a archivo", e);
            return false;
        } catch (Exception e) {
            Log.e(TAG, "Error inesperado guardando imagen", e);
            return false;
        }
    }
    
    /**
     * Calcula el tamaño en bytes de un bitmap
     */
    public static long getBitmapSize(Bitmap bitmap) {
        if (bitmap == null || bitmap.isRecycled()) {
            return 0;
        }
        
        try {
            // Para Android 4.2.2, usar método compatible
            return bitmap.getRowBytes() * bitmap.getHeight();
        } catch (Exception e) {
            Log.e(TAG, "Error calculando tamaño del bitmap", e);
            return 0;
        }
    }
    
    /**
     * Libera recursos de bitmap de manera segura
     */
    public static void recycleBitmap(Bitmap bitmap) {
        if (bitmap != null && !bitmap.isRecycled()) {
            try {
                bitmap.recycle();
                Log.d(TAG, "Bitmap reciclado correctamente");
            } catch (Exception e) {
                Log.e(TAG, "Error reciclando bitmap", e);
            }
        }
    }
    
    /**
     * Convierte bitmap a byte array con compresión
     */
    public static byte[] bitmapToByteArray(Bitmap bitmap, int quality) {
        if (bitmap == null) {
            return null;
        }
        
        try {
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, quality, stream);
            byte[] byteArray = stream.toByteArray();
            stream.close();
            
            return byteArray;
            
        } catch (Exception e) {
            Log.e(TAG, "Error convirtiendo bitmap a byte array", e);
            return null;
        }
    }
    
    /**
     * Verifica si hay suficiente memoria disponible para procesar una imagen
     */
    public static boolean hasEnoughMemoryForImage(int width, int height) {
        try {
            Runtime runtime = Runtime.getRuntime();
            long usedMemory = runtime.totalMemory() - runtime.freeMemory();
            long maxMemory = runtime.maxMemory();
            long availableMemory = maxMemory - usedMemory;
            
            // Estimar memoria necesaria para la imagen (4 bytes por pixel)
            long imageMemory = width * height * 4;
            
            // Dejar un margen del 20% para operaciones adicionales
            boolean hasEnough = availableMemory > (imageMemory * 1.2);
            
            Log.d(TAG, String.format(
                "Memoria - Disponible: %d MB, Necesaria: %d MB, Suficiente: %b",
                availableMemory / (1024 * 1024),
                imageMemory / (1024 * 1024),
                hasEnough
            ));
            
            return hasEnough;
            
        } catch (Exception e) {
            Log.e(TAG, "Error verificando memoria disponible", e);
            return false;
        }
    }
}
