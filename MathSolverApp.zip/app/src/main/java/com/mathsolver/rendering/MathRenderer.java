package com.mathsolver.rendering;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.text.Html;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.StyleSpan;
import android.text.style.TypefaceSpan;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.mathsolver.models.MathSolution;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Renderizador de matemáticas optimizado para Android 4.2.2
 * Proporciona renderizado de texto con formato mejorado y LaTeX básico
 * Optimizado para dispositivos de baja RAM
 */
public class MathRenderer {
    
    private static final String TAG = "MathRenderer";
    
    private final Context context;
    private final Paint textPaint;
    private final Paint formulaPaint;
    
    // Configuración de estilo
    private static final int DEFAULT_TEXT_SIZE = 16;
    private static final int FORMULA_TEXT_SIZE = 18;
    private static final int TITLE_TEXT_SIZE = 20;
    private static final int MARGIN = 16;
    private static final int LINE_SPACING = 8;
    
    // Colores del tema
    private static final int TEXT_COLOR = Color.parseColor("#2E3B4E");
    private static final int FORMULA_COLOR = Color.parseColor("#2E3B4E");
    private static final int BACKGROUND_COLOR = Color.parseColor("#FAFBFC");
    private static final int BORDER_COLOR = Color.parseColor("#E1E5E9");
    
    public MathRenderer(Context context) {
        this.context = context;
        
        // Configurar paint para texto normal
        this.textPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        this.textPaint.setColor(TEXT_COLOR);
        this.textPaint.setTextSize(DEFAULT_TEXT_SIZE * context.getResources().getDisplayMetrics().density);
        this.textPaint.setTypeface(Typeface.DEFAULT);
        
        // Configurar paint para fórmulas
        this.formulaPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        this.formulaPaint.setColor(FORMULA_COLOR);
        this.formulaPaint.setTextSize(FORMULA_TEXT_SIZE * context.getResources().getDisplayMetrics().density);
        this.formulaPaint.setTypeface(Typeface.MONOSPACE);
    }
    
    /**
     * Renderiza una solución matemática completa en un contenedor LinearLayout
     */
    public void renderSolutionToLayout(MathSolution solution, LinearLayout container) {
        if (solution == null || container == null) {
            Log.e(TAG, "Solución o contenedor nulos");
            return;
        }
        
        try {
            // Limpiar contenedor
            container.removeAllViews();
            
            // Agregar problema original
            if (!TextUtils.isEmpty(solution.getOriginalProblem())) {
                addSectionToLayout(container, "Problema:", solution.getOriginalProblem(), false);
            }
            
            // Agregar solución principal
            if (!TextUtils.isEmpty(solution.getSolution())) {
                addSectionToLayout(container, "Solución:", solution.getSolution(), true);
            }
            
            // Agregar pasos si existen
            if (solution.getSteps() != null && !solution.getSteps().isEmpty()) {
                addStepsToLayout(container, solution.getSteps());
            }
            
            // Agregar explicación si existe
            if (!TextUtils.isEmpty(solution.getExplanation())) {
                addSectionToLayout(container, "Explicación:", solution.getExplanation(), false);
            }
            
            Log.d(TAG, "Solución renderizada correctamente");
            
        } catch (Exception e) {
            Log.e(TAG, "Error renderizando solución", e);
            
            // Agregar mensaje de error como fallback
            TextView errorView = createStyledTextView("Error al renderizar la solución", DEFAULT_TEXT_SIZE, false);
            container.addView(errorView);
        }
    }
    
    /**
     * Agrega una sección con título y contenido al layout
     */
    private void addSectionToLayout(LinearLayout container, String title, String content, boolean isFormula) {
        try {
            // Agregar título
            TextView titleView = createStyledTextView(title, TITLE_TEXT_SIZE, true);
            titleView.setTextColor(TEXT_COLOR);
            container.addView(titleView);
            
            // Agregar espaciado
            container.addView(createSpacer(LINE_SPACING));
            
            // Procesar y agregar contenido
            List<View> contentViews = processContent(content, isFormula);
            for (View view : contentViews) {
                container.addView(view);
            }
            
            // Agregar espaciado final
            container.addView(createSpacer(MARGIN));
            
        } catch (Exception e) {
            Log.e(TAG, "Error agregando sección: " + title, e);
        }
    }
    
    /**
     * Agrega pasos numerados al layout
     */
    private void addStepsToLayout(LinearLayout container, List<String> steps) {
        try {
            // Título de pasos
            TextView titleView = createStyledTextView("Pasos de la solución:", TITLE_TEXT_SIZE, true);
            container.addView(titleView);
            container.addView(createSpacer(LINE_SPACING));
            
            // Agregar cada paso
            for (int i = 0; i < steps.size(); i++) {
                String stepText = "Paso " + (i + 1) + ": " + steps.get(i);
                
                TextView stepView = createStyledTextView(stepText, DEFAULT_TEXT_SIZE, false);
                stepView.setPadding(MARGIN, LINE_SPACING, MARGIN, LINE_SPACING);
                stepView.setBackgroundColor(BACKGROUND_COLOR);
                
                container.addView(stepView);
                container.addView(createSpacer(LINE_SPACING / 2));
            }
            
            container.addView(createSpacer(MARGIN));
            
        } catch (Exception e) {
            Log.e(TAG, "Error agregando pasos", e);
        }
    }
    
    /**
     * Procesa el contenido y lo convierte en vistas apropiadas
     */
    private List<View> processContent(String content, boolean isFormula) {
        List<View> views = new ArrayList<View>();
        
        try {
            if (TextUtils.isEmpty(content)) {
                return views;
            }
            
            // Si contiene LaTeX básico, intentar procesarlo
            if (isFormula && containsLatex(content)) {
                views.addAll(processLatexContent(content));
            } else {
                // Procesar como texto normal con formato mejorado
                views.addAll(processFormattedText(content));
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error procesando contenido", e);
            
            // Fallback: crear vista de texto simple
            TextView fallbackView = createStyledTextView(content, DEFAULT_TEXT_SIZE, false);
            views.add(fallbackView);
        }
        
        return views;
    }
    
    /**
     * Procesa contenido con LaTeX básico
     */
    private List<View> processLatexContent(String content) {
        List<View> views = new ArrayList<View>();
        
        try {
            // Dividir el contenido en segmentos de LaTeX y texto normal
            List<ContentSegment> segments = parseLatexSegments(content);
            
            for (ContentSegment segment : segments) {
                if (segment.isLatex) {
                    // Renderizar LaTeX como texto con formato especial
                    TextView latexView = createLatexTextView(segment.content);
                    views.add(latexView);
                } else {
                    // Renderizar como texto normal
                    TextView textView = createStyledTextView(segment.content, DEFAULT_TEXT_SIZE, false);
                    views.add(textView);
                }
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error procesando LaTeX", e);
            
            // Fallback: texto simple
            TextView fallbackView = createStyledTextView(content, DEFAULT_TEXT_SIZE, false);
            views.add(fallbackView);
        }
        
        return views;
    }
    
    /**
     * Procesa texto con formato HTML básico
     */
    private List<View> processFormattedText(String content) {
        List<View> views = new ArrayList<View>();
        
        try {
            // Dividir por párrafos
            String[] paragraphs = content.split("\n\n");
            
            for (String paragraph : paragraphs) {
                if (TextUtils.isEmpty(paragraph.trim())) {
                    continue;
                }
                
                // Aplicar formato básico
                Spanned formattedText = applyBasicFormatting(paragraph.trim());
                
                TextView textView = new TextView(context);
                textView.setText(formattedText);
                textView.setTextSize(DEFAULT_TEXT_SIZE);
                textView.setTextColor(TEXT_COLOR);
                textView.setPadding(MARGIN, LINE_SPACING, MARGIN, LINE_SPACING);
                textView.setLineSpacing(LINE_SPACING, 1.0f);
                
                views.add(textView);
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error procesando texto formateado", e);
            
            TextView fallbackView = createStyledTextView(content, DEFAULT_TEXT_SIZE, false);
            views.add(fallbackView);
        }
        
        return views;
    }
    
    /**
     * Aplica formato básico al texto (negrita, cursiva, etc.)
     */
    private Spanned applyBasicFormatting(String text) {
        try {
            // Reemplazar marcadores comunes con HTML
            text = text.replaceAll("\\*\\*(.*?)\\*\\*", "<b>$1</b>");  // **negrita**
            text = text.replaceAll("\\*(.*?)\\*", "<i>$1</i>");        // *cursiva*
            text = text.replaceAll("_(.*?)_", "<u>$1</u>");            // _subrayado_
            
            // Convertir ecuaciones simples a formato monospace
            text = text.replaceAll("([0-9]+[+\\-*/=][0-9]+[^\\s]*)", "<tt>$1</tt>");
            
            return Html.fromHtml(text);
            
        } catch (Exception e) {
            Log.e(TAG, "Error aplicando formato básico", e);
            return new SpannableString(text);
        }
    }
    
    /**
     * Crea una vista de texto para renderizado de LaTeX básico
     */
    private TextView createLatexTextView(String latexContent) {
        TextView textView = new TextView(context);
        
        try {
            // Procesar LaTeX básico y convertir a texto con formato
            String processedText = processBasicLatex(latexContent);
            
            textView.setText(processedText);
            textView.setTextSize(FORMULA_TEXT_SIZE);
            textView.setTextColor(FORMULA_COLOR);
            textView.setTypeface(Typeface.MONOSPACE);
            textView.setPadding(MARGIN, LINE_SPACING, MARGIN, LINE_SPACING);
            textView.setBackgroundColor(BACKGROUND_COLOR);
            textView.setLineSpacing(LINE_SPACING, 1.2f);
            
        } catch (Exception e) {
            Log.e(TAG, "Error creando vista LaTeX", e);
            textView.setText(latexContent);
            textView.setTextSize(DEFAULT_TEXT_SIZE);
            textView.setTextColor(TEXT_COLOR);
        }
        
        return textView;
    }
    
    /**
     * Procesa LaTeX básico y lo convierte a texto legible
     */
    private String processBasicLatex(String latex) {
        try {
            String processed = latex;
            
            // Remover delimitadores de LaTeX
            processed = processed.replaceAll("\\$\\$", "");
            processed = processed.replaceAll("\\$", "");
            processed = processed.replaceAll("\\\\\\[", "");
            processed = processed.replaceAll("\\\\\\]", "");
            
            // Convertir comandos LaTeX comunes
            processed = processed.replaceAll("\\\\frac\\{([^}]+)\\}\\{([^}]+)\\}", "($1)/($2)");
            processed = processed.replaceAll("\\\\sqrt\\{([^}]+)\\}", "√($1)");
            processed = processed.replaceAll("\\\\sum", "Σ");
            processed = processed.replaceAll("\\\\int", "∫");
            processed = processed.replaceAll("\\\\infty", "∞");
            processed = processed.replaceAll("\\\\pi", "π");
            processed = processed.replaceAll("\\\\alpha", "α");
            processed = processed.replaceAll("\\\\beta", "β");
            processed = processed.replaceAll("\\\\gamma", "γ");
            processed = processed.replaceAll("\\\\delta", "δ");
            processed = processed.replaceAll("\\\\theta", "θ");
            processed = processed.replaceAll("\\\\lambda", "λ");
            processed = processed.replaceAll("\\\\mu", "μ");
            processed = processed.replaceAll("\\\\sigma", "σ");
            processed = processed.replaceAll("\\\\omega", "ω");
            
            // Convertir superíndices y subíndices básicos
            processed = processed.replaceAll("\\^\\{([^}]+)\\}", "^($1)");
            processed = processed.replaceAll("_\\{([^}]+)\\}", "_($1)");
            
            // Limpiar comandos LaTeX restantes
            processed = processed.replaceAll("\\\\[a-zA-Z]+", "");
            processed = processed.replaceAll("\\{", "(");
            processed = processed.replaceAll("\\}", ")");
            
            return processed;
            
        } catch (Exception e) {
            Log.e(TAG, "Error procesando LaTeX básico", e);
            return latex;
        }
    }
    
    /**
     * Verifica si el contenido contiene LaTeX
     */
    private boolean containsLatex(String content) {
        if (TextUtils.isEmpty(content)) {
            return false;
        }
        
        return content.contains("\\") || 
               content.contains("$") || 
               content.contains("frac") ||
               content.contains("sqrt") ||
               content.contains("sum") ||
               content.contains("int");
    }
    
    /**
     * Parsea segmentos de LaTeX del contenido
     */
    private List<ContentSegment> parseLatexSegments(String content) {
        List<ContentSegment> segments = new ArrayList<ContentSegment>();
        
        try {
            // Patrones para detectar LaTeX
            Pattern latexPattern = Pattern.compile("(\\$\\$[^$]+\\$\\$|\\$[^$]+\\$|\\\\\\[[^\\]]+\\\\\\])");
            Matcher matcher = latexPattern.matcher(content);
            
            int lastEnd = 0;
            
            while (matcher.find()) {
                // Agregar texto antes del LaTeX
                if (matcher.start() > lastEnd) {
                    String textBefore = content.substring(lastEnd, matcher.start());
                    if (!TextUtils.isEmpty(textBefore.trim())) {
                        segments.add(new ContentSegment(textBefore, false));
                    }
                }
                
                // Agregar LaTeX
                String latexContent = matcher.group(1);
                segments.add(new ContentSegment(latexContent, true));
                
                lastEnd = matcher.end();
            }
            
            // Agregar texto restante
            if (lastEnd < content.length()) {
                String textAfter = content.substring(lastEnd);
                if (!TextUtils.isEmpty(textAfter.trim())) {
                    segments.add(new ContentSegment(textAfter, false));
                }
            }
            
            // Si no se encontró LaTeX, agregar todo como texto
            if (segments.isEmpty()) {
                segments.add(new ContentSegment(content, false));
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error parseando segmentos LaTeX", e);
            segments.clear();
            segments.add(new ContentSegment(content, false));
        }
        
        return segments;
    }
    
    /**
     * Crea una TextView con estilo personalizado
     */
    private TextView createStyledTextView(String text, int textSize, boolean isBold) {
        TextView textView = new TextView(context);
        textView.setText(text);
        textView.setTextSize(textSize);
        textView.setTextColor(TEXT_COLOR);
        textView.setPadding(MARGIN, LINE_SPACING, MARGIN, LINE_SPACING);
        textView.setLineSpacing(LINE_SPACING, 1.1f);
        
        if (isBold) {
            textView.setTypeface(Typeface.DEFAULT_BOLD);
        }
        
        return textView;
    }
    
    /**
     * Crea un espaciador vertical
     */
    private View createSpacer(int height) {
        View spacer = new View(context);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 
            height
        );
        spacer.setLayoutParams(params);
        return spacer;
    }
    
    /**
     * Clase auxiliar para segmentos de contenido
     */
    private static class ContentSegment {
        final String content;
        final boolean isLatex;
        
        ContentSegment(String content, boolean isLatex) {
            this.content = content;
            this.isLatex = isLatex;
        }
    }
}
