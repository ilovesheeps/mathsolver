package com.mathsolver.api;

import android.graphics.Bitmap;
import android.util.Base64;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.mathsolver.models.MathSolution;
import com.mathsolver.utils.ImageUtils;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import com.squareup.okhttp.Call;
import com.squareup.okhttp.Callback;
import com.squareup.okhttp.MediaType;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.RequestBody;
import com.squareup.okhttp.Response;

/**
 * Cliente optimizado para la API de Gemini 1.5 Flash
 * Diseñado específicamente para Android 4.2.2 con gestión de memoria y rate limiting
 */
public class GeminiApiClient {
    
    private static final String TAG = "GeminiApiClient";
    private static final String API_KEY = "AIzaSyBSN3vG3Tr8EBwH0EXavE7PS4d0Tu_A6_I";
    private static final String MODEL = "gemini-1.5-flash";
    private static final String BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/";
    
    // Configuración para dispositivos de baja RAM
    private static final int MAX_RETRIES = 3;
    private static final int RATE_LIMIT_DELAY = 4000; // 4 segundos
    private static final int CONNECTION_TIMEOUT = 30; // 30 segundos
    private static final int READ_TIMEOUT = 60; // 60 segundos
    private static final int MAX_IMAGE_SIZE = 1024; // 1024px máximo
    private static final int JPEG_QUALITY = 85; // Calidad optimizada
    
    private final OkHttpClient httpClient;
    private final Gson gson;
    private long lastRequestTime = 0;
    
    public interface MathSolutionCallback {
        void onSuccess(MathSolution solution);
        void onError(String error);
        void onProgress(String message);
    }
    
    public GeminiApiClient() {
        // Configurar cliente HTTP para Android 4.2.2
        this.httpClient = new OkHttpClient();
        this.httpClient.setConnectTimeout(CONNECTION_TIMEOUT, TimeUnit.SECONDS);
        this.httpClient.setReadTimeout(READ_TIMEOUT, TimeUnit.SECONDS);
        this.httpClient.setWriteTimeout(READ_TIMEOUT, TimeUnit.SECONDS);
        
        this.gson = new Gson();
    }
    
    /**
     * Resuelve un problema matemático a partir de una imagen
     */
    public void solveMathProblem(Bitmap image, MathSolutionCallback callback) {
        if (image == null) {
            callback.onError("Imagen no válida");
            return;
        }
        
        // Aplicar rate limiting
        enforceRateLimit();
        
        try {
            callback.onProgress("Preparando imagen...");
            
            // Comprimir imagen para dispositivos antiguos
            Bitmap compressedImage = ImageUtils.compressForOldDevices(image, MAX_IMAGE_SIZE);
            
            callback.onProgress("Convirtiendo imagen...");
            
            // Convertir a base64 optimizado
            String base64Image = bitmapToBase64Optimized(compressedImage);
            
            if (base64Image == null) {
                callback.onError("Error al procesar la imagen");
                return;
            }
            
            callback.onProgress("Enviando a Gemini AI...");
            
            // Enviar solicitud
            sendAnalysisRequest(base64Image, callback, 0);
            
        } catch (Exception e) {
            Log.e(TAG, "Error en solveMathProblem", e);
            callback.onError("Error al procesar: " + e.getMessage());
        }
    }
    
    /**
     * Envía la solicitud de análisis a Gemini con reintentos
     */
    private void sendAnalysisRequest(String base64Image, MathSolutionCallback callback, int attempt) {
        if (attempt >= MAX_RETRIES) {
            callback.onError("Error de red después de " + MAX_RETRIES + " intentos");
            return;
        }
        
        try {
            String url = BASE_URL + MODEL + ":generateContent?key=" + API_KEY;
            
            // Crear payload JSON optimizado
            JsonObject requestPayload = createRequestPayload(base64Image);
            String jsonPayload = gson.toJson(requestPayload);
            
            Log.d(TAG, "Enviando solicitud (intento " + (attempt + 1) + ")");
            
            RequestBody body = RequestBody.create(
                MediaType.parse("application/json"), 
                jsonPayload
            );
            
            Request request = new Request.Builder()
                .url(url)
                .post(body)
                .addHeader("Content-Type", "application/json")
                .build();
            
            httpClient.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Request request, IOException e) {
                    Log.e(TAG, "Fallo en la solicitud HTTP", e);
                    
                    if (attempt < MAX_RETRIES - 1) {
                        // Reintentar con delay exponencial
                        try {
                            Thread.sleep(RATE_LIMIT_DELAY * (attempt + 1));
                        } catch (InterruptedException ie) {
                            Thread.currentThread().interrupt();
                        }
                        sendAnalysisRequest(base64Image, callback, attempt + 1);
                    } else {
                        callback.onError("Error de conexión: " + e.getMessage());
                    }
                }
                
                @Override
                public void onResponse(Response response) throws IOException {
                    try {
                        if (!response.isSuccessful()) {
                            String errorBody = response.body().string();
                            Log.e(TAG, "Error HTTP " + response.code() + ": " + errorBody);
                            
                            if (response.code() == 429 && attempt < MAX_RETRIES - 1) {
                                // Rate limit hit, reintentar
                                Thread.sleep(RATE_LIMIT_DELAY * 2);
                                sendAnalysisRequest(base64Image, callback, attempt + 1);
                                return;
                            }
                            
                            callback.onError("Error del servidor: " + response.code());
                            return;
                        }
                        
                        String responseBody = response.body().string();
                        Log.d(TAG, "Respuesta recibida: " + responseBody.substring(0, Math.min(200, responseBody.length())));
                        
                        callback.onProgress("Procesando respuesta...");
                        
                        // Parsear respuesta y crear solución
                        MathSolution solution = parseGeminiResponse(responseBody);
                        
                        if (solution != null && solution.isValid()) {
                            callback.onSuccess(solution);
                        } else {
                            callback.onError("No se pudo procesar la respuesta de Gemini");
                        }
                        
                    } catch (Exception e) {
                        Log.e(TAG, "Error procesando respuesta", e);
                        callback.onError("Error procesando respuesta: " + e.getMessage());
                    }
                }
            });
            
        } catch (Exception e) {
            Log.e(TAG, "Error creando solicitud", e);
            callback.onError("Error interno: " + e.getMessage());
        }
    }
    
    /**
     * Crea el payload JSON para la API de Gemini
     */
    private JsonObject createRequestPayload(String base64Image) {
        JsonObject payload = new JsonObject();
        
        // Configurar el contenido
        JsonArray contents = new JsonArray();
        JsonObject content = new JsonObject();
        
        JsonArray parts = new JsonArray();
        
        // Parte de texto con prompt optimizado para matemáticas
        JsonObject textPart = new JsonObject();
        textPart.addProperty("text", 
            "Eres un experto tutor de matemáticas. Analiza esta imagen y resuelve todos los ejercicios matemáticos que encuentres. " +
            "Proporciona:\n" +
            "1. Una solución paso a paso clara y detallada\n" +
            "2. Explica cada paso del proceso\n" +
            "3. Si hay múltiples problemas, resuélvelos todos\n" +
            "4. Incluye el resultado final\n" +
            "5. Usa formato LaTeX cuando sea apropiado para ecuaciones\n\n" +
            "Formato de respuesta:\n" +
            "PROBLEMA: [describe el problema]\n" +
            "SOLUCIÓN: [resultado final]\n" +
            "PASOS:\n" +
            "Paso 1: [explicación]\n" +
            "Paso 2: [explicación]\n" +
            "...\n" +
            "EXPLICACIÓN: [conceptos clave utilizados]"
        );
        parts.add(textPart);
        
        // Parte de imagen
        JsonObject imagePart = new JsonObject();
        JsonObject inlineData = new JsonObject();
        inlineData.addProperty("mime_type", "image/jpeg");
        inlineData.addProperty("data", base64Image);
        imagePart.add("inline_data", inlineData);
        parts.add(imagePart);
        
        content.add("parts", parts);
        contents.add(content);
        payload.add("contents", contents);
        
        // Configuración de generación optimizada
        JsonObject generationConfig = new JsonObject();
        generationConfig.addProperty("temperature", 0.1);
        generationConfig.addProperty("topK", 32);
        generationConfig.addProperty("topP", 1.0);
        generationConfig.addProperty("maxOutputTokens", 2048);
        payload.add("generationConfig", generationConfig);
        
        return payload;
    }
    
    /**
     * Parsea la respuesta de Gemini y crea un objeto MathSolution
     */
    private MathSolution parseGeminiResponse(String responseJson) {
        try {
            JsonObject response = gson.fromJson(responseJson, JsonObject.class);
            
            if (!response.has("candidates") || response.get("candidates").isJsonNull()) {
                Log.e(TAG, "No hay candidatos en la respuesta");
                return null;
            }
            
            JsonArray candidates = response.getAsJsonArray("candidates");
            if (candidates.size() == 0) {
                Log.e(TAG, "Array de candidatos vacío");
                return null;
            }
            
            JsonObject candidate = candidates.get(0).getAsJsonObject();
            if (!candidate.has("content")) {
                Log.e(TAG, "No hay contenido en el candidato");
                return null;
            }
            
            JsonObject content = candidate.getAsJsonObject("content");
            if (!content.has("parts")) {
                Log.e(TAG, "No hay partes en el contenido");
                return null;
            }
            
            JsonArray parts = content.getAsJsonArray("parts");
            if (parts.size() == 0) {
                Log.e(TAG, "Array de partes vacío");
                return null;
            }
            
            JsonObject part = parts.get(0).getAsJsonObject();
            if (!part.has("text")) {
                Log.e(TAG, "No hay texto en la parte");
                return null;
            }
            
            String responseText = part.get("text").getAsString();
            Log.d(TAG, "Texto de respuesta: " + responseText);
            
            return parseMathSolutionFromText(responseText);
            
        } catch (Exception e) {
            Log.e(TAG, "Error parseando respuesta JSON", e);
            return null;
        }
    }
    
    /**
     * Extrae información estructurada del texto de respuesta
     */
    private MathSolution parseMathSolutionFromText(String responseText) {
        try {
            MathSolution solution = new MathSolution();
            
            // Extraer problema
            String problem = extractSection(responseText, "PROBLEMA:", "SOLUCIÓN:");
            if (problem.isEmpty()) {
                problem = "Problema detectado en la imagen";
            }
            solution.setOriginalProblem(problem);
            
            // Extraer solución
            String solutionText = extractSection(responseText, "SOLUCIÓN:", "PASOS:");
            if (solutionText.isEmpty()) {
                solutionText = extractSection(responseText, "SOLUCIÓN:", "EXPLICACIÓN:");
            }
            if (solutionText.isEmpty()) {
                // Si no encuentra formato específico, usar toda la respuesta
                solutionText = responseText;
            }
            solution.setSolution(solutionText);
            
            // Extraer pasos
            String stepsText = extractSection(responseText, "PASOS:", "EXPLICACIÓN:");
            if (!stepsText.isEmpty()) {
                List<String> steps = parseSteps(stepsText);
                solution.setSteps(steps);
            }
            
            // Extraer explicación
            String explanation = extractSectionToEnd(responseText, "EXPLICACIÓN:");
            if (!explanation.isEmpty()) {
                solution.setExplanation(explanation);
            }
            
            // Detectar LaTeX en la respuesta
            if (responseText.contains("\\") || responseText.contains("$")) {
                solution.setLatexSolution(responseText);
            }
            
            return solution;
            
        } catch (Exception e) {
            Log.e(TAG, "Error parseando texto de solución", e);
            
            // Crear solución básica si el parsing falla
            MathSolution fallbackSolution = new MathSolution();
            fallbackSolution.setOriginalProblem("Problema detectado en la imagen");
            fallbackSolution.setSolution(responseText);
            return fallbackSolution;
        }
    }
    
    /**
     * Extrae una sección específica del texto
     */
    private String extractSection(String text, String startMarker, String endMarker) {
        try {
            int startIndex = text.indexOf(startMarker);
            if (startIndex == -1) return "";
            
            startIndex += startMarker.length();
            
            int endIndex = text.indexOf(endMarker, startIndex);
            if (endIndex == -1) {
                return text.substring(startIndex).trim();
            }
            
            return text.substring(startIndex, endIndex).trim();
        } catch (Exception e) {
            return "";
        }
    }
    
    /**
     * Extrae sección hasta el final del texto
     */
    private String extractSectionToEnd(String text, String startMarker) {
        try {
            int startIndex = text.indexOf(startMarker);
            if (startIndex == -1) return "";
            
            startIndex += startMarker.length();
            return text.substring(startIndex).trim();
        } catch (Exception e) {
            return "";
        }
    }
    
    /**
     * Parsea los pasos de la solución
     */
    private List<String> parseSteps(String stepsText) {
        List<String> steps = new ArrayList<String>();
        
        try {
            String[] lines = stepsText.split("\n");
            StringBuilder currentStep = new StringBuilder();
            
            for (String line : lines) {
                line = line.trim();
                if (line.isEmpty()) continue;
                
                if (line.toLowerCase().startsWith("paso ")) {
                    if (currentStep.length() > 0) {
                        steps.add(currentStep.toString().trim());
                        currentStep = new StringBuilder();
                    }
                    // Remover "Paso X:" del inicio
                    int colonIndex = line.indexOf(":");
                    if (colonIndex != -1 && colonIndex < line.length() - 1) {
                        currentStep.append(line.substring(colonIndex + 1).trim());
                    }
                } else {
                    if (currentStep.length() > 0) {
                        currentStep.append(" ");
                    }
                    currentStep.append(line);
                }
            }
            
            if (currentStep.length() > 0) {
                steps.add(currentStep.toString().trim());
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error parseando pasos", e);
        }
        
        return steps;
    }
    
    /**
     * Convierte bitmap a base64 optimizado para dispositivos antiguos
     */
    private String bitmapToBase64Optimized(Bitmap bitmap) {
        try {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, byteArrayOutputStream);
            byte[] byteArray = byteArrayOutputStream.toByteArray();
            
            String base64 = Base64.encodeToString(byteArray, Base64.NO_WRAP);
            
            // Liberar recursos inmediatamente en dispositivos antiguos
            byteArrayOutputStream.close();
            
            Log.d(TAG, "Imagen convertida a base64, tamaño: " + byteArray.length + " bytes");
            
            return base64;
            
        } catch (Exception e) {
            Log.e(TAG, "Error convirtiendo bitmap a base64", e);
            return null;
        }
    }
    
    /**
     * Aplica rate limiting para evitar límites de API
     */
    private void enforceRateLimit() {
        long currentTime = System.currentTimeMillis();
        long timeSinceLastRequest = currentTime - lastRequestTime;
        
        if (timeSinceLastRequest < RATE_LIMIT_DELAY) {
            try {
                long sleepTime = RATE_LIMIT_DELAY - timeSinceLastRequest;
                Log.d(TAG, "Aplicando rate limit, esperando " + sleepTime + "ms");
                Thread.sleep(sleepTime);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
        
        lastRequestTime = System.currentTimeMillis();
    }
}
