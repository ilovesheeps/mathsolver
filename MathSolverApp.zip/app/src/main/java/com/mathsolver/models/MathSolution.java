package com.mathsolver.models;

import java.io.Serializable;
import java.util.List;
import java.util.ArrayList;

/**
 * Modelo de datos para soluciones matemáticas
 * Compatible con Android 4.2.2 (API 17)
 */
public class MathSolution implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private String originalProblem;
    private String solution;
    private List<String> steps;
    private String explanation;
    private String latexSolution;
    private boolean hasLatex;
    private long timestamp;
    
    public MathSolution() {
        this.steps = new ArrayList<String>();
        this.timestamp = System.currentTimeMillis();
        this.hasLatex = false;
    }
    
    public MathSolution(String originalProblem, String solution) {
        this();
        this.originalProblem = originalProblem;
        this.solution = solution;
    }
    
    // Getters
    public String getOriginalProblem() {
        return originalProblem;
    }
    
    public String getSolution() {
        return solution;
    }
    
    public List<String> getSteps() {
        return steps;
    }
    
    public String getExplanation() {
        return explanation;
    }
    
    public String getLatexSolution() {
        return latexSolution;
    }
    
    public boolean hasLatex() {
        return hasLatex;
    }
    
    public long getTimestamp() {
        return timestamp;
    }
    
    // Setters
    public void setOriginalProblem(String originalProblem) {
        this.originalProblem = originalProblem;
    }
    
    public void setSolution(String solution) {
        this.solution = solution;
    }
    
    public void setSteps(List<String> steps) {
        this.steps = steps != null ? steps : new ArrayList<String>();
    }
    
    public void addStep(String step) {
        if (step != null && !step.trim().isEmpty()) {
            this.steps.add(step.trim());
        }
    }
    
    public void setExplanation(String explanation) {
        this.explanation = explanation;
    }
    
    public void setLatexSolution(String latexSolution) {
        this.latexSolution = latexSolution;
        this.hasLatex = (latexSolution != null && !latexSolution.trim().isEmpty());
    }
    
    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }
    
    // Métodos de utilidad
    public boolean isValid() {
        return originalProblem != null && !originalProblem.trim().isEmpty() &&
               solution != null && !solution.trim().isEmpty();
    }
    
    public String getFormattedSteps() {
        if (steps == null || steps.isEmpty()) {
            return "Sin pasos específicos disponibles.";
        }
        
        StringBuilder formatted = new StringBuilder();
        for (int i = 0; i < steps.size(); i++) {
            formatted.append("Paso ").append(i + 1).append(": ").append(steps.get(i));
            if (i < steps.size() - 1) {
                formatted.append("\n\n");
            }
        }
        return formatted.toString();
    }
    
    public String getFullSolutionText() {
        StringBuilder fullText = new StringBuilder();
        
        if (originalProblem != null) {
            fullText.append("PROBLEMA:\n").append(originalProblem).append("\n\n");
        }
        
        if (solution != null) {
            fullText.append("SOLUCIÓN:\n").append(solution).append("\n\n");
        }
        
        if (steps != null && !steps.isEmpty()) {
            fullText.append("PASOS:\n").append(getFormattedSteps()).append("\n\n");
        }
        
        if (explanation != null && !explanation.trim().isEmpty()) {
            fullText.append("EXPLICACIÓN:\n").append(explanation);
        }
        
        return fullText.toString();
    }
    
    @Override
    public String toString() {
        return "MathSolution{" +
                "originalProblem='" + originalProblem + '\'' +
                ", solution='" + solution + '\'' +
                ", stepsCount=" + (steps != null ? steps.size() : 0) +
                ", hasLatex=" + hasLatex +
                ", timestamp=" + timestamp +
                '}';
    }
}
