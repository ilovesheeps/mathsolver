package com.mathsolver;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.mathsolver.R;
import com.mathsolver.models.MathSolution;
import com.mathsolver.rendering.MathRenderer;
import com.mathsolver.utils.ImageUtils;

/**
 * Actividad que muestra la solución del problema matemático
 * Optimizada para Android 4.2.2 con renderizado eficiente
 */
public class SolutionActivity extends ActionBarActivity {
    
    private static final String TAG = "SolutionActivity";
    
    // Componentes de UI
    private ImageView ivOriginalProblem;
    private LinearLayout layoutMathSolution;
    private LinearLayout layoutRendering;
    private LinearLayout layoutAdditionalInfo;
    private Button btnNewProblem;
    private Button btnShareSolution;
    
    // Variables de estado
    private MathSolution currentSolution;
    private String originalImagePath;
    private MathRenderer mathRenderer;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_solution);
        
        Log.d(TAG, "SolutionActivity creada");
        
        // Configurar action bar
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(getString(R.string.solution_title));
        }
        
        // Inicializar componentes
        initializeViews();
        initializeMathRenderer();
        setupClickListeners();
        
        // Procesar datos de entrada
        processIntentData();
    }
    
    /**
     * Inicializa las vistas de la interfaz
     */
    private void initializeViews() {
        try {
            ivOriginalProblem = (ImageView) findViewById(R.id.iv_original_problem);
            layoutMathSolution = (LinearLayout) findViewById(R.id.layout_math_solution);
            layoutRendering = (LinearLayout) findViewById(R.id.layout_rendering);
            layoutAdditionalInfo = (LinearLayout) findViewById(R.id.layout_additional_info);
            btnNewProblem = (Button) findViewById(R.id.btn_new_problem);
            btnShareSolution = (Button) findViewById(R.id.btn_share_solution);
            
            // Estado inicial
            layoutRendering.setVisibility(View.VISIBLE);
            layoutAdditionalInfo.setVisibility(View.GONE);
            
            Log.d(TAG, "Vistas inicializadas correctamente");
            
        } catch (Exception e) {
            Log.e(TAG, "Error inicializando vistas", e);
            showErrorAndFinish("Error inicializando interfaz");
        }
    }
    
    /**
     * Inicializa el renderizador de matemáticas
     */
    private void initializeMathRenderer() {
        try {
            mathRenderer = new MathRenderer(this);
            Log.d(TAG, "Renderizador de matemáticas inicializado");
        } catch (Exception e) {
            Log.e(TAG, "Error inicializando renderizador", e);
            showErrorAndFinish("Error inicializando renderizador de matemáticas");
        }
    }
    
    /**
     * Configura los listeners de los botones
     */
    private void setupClickListeners() {
        btnNewProblem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onNewProblemClicked();
            }
        });
        
        btnShareSolution.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onShareSolutionClicked();
            }
        });
    }
    
    /**
     * Procesa los datos pasados en el Intent
     */
    private void processIntentData() {
        try {
            Intent intent = getIntent();
            
            if (intent == null) {
                Log.e(TAG, "Intent es null");
                showErrorAndFinish("Error: no se recibieron datos");
                return;
            }
            
            // Obtener solución
            currentSolution = (MathSolution) intent.getSerializableExtra("solution");
            originalImagePath = intent.getStringExtra("image_path");
            
            if (currentSolution == null) {
                Log.e(TAG, "Solución es null");
                showErrorAndFinish("Error: no se recibió la solución");
                return;
            }
            
            Log.d(TAG, "Datos procesados - Solución: " + currentSolution.toString());
            
            // Cargar imagen original
            loadOriginalImage();
            
            // Renderizar solución
            renderSolution();
            
        } catch (Exception e) {
            Log.e(TAG, "Error procesando datos del intent", e);
            showErrorAndFinish("Error procesando datos de entrada");
        }
    }
    
    /**
     * Carga y muestra la imagen original del problema
     */
    private void loadOriginalImage() {
        try {
            if (!TextUtils.isEmpty(originalImagePath)) {
                // Cargar imagen de archivo
                Bitmap originalBitmap = ImageUtils.loadBitmapFromFile(originalImagePath, 800);
                
                if (originalBitmap != null) {
                    ivOriginalProblem.setImageBitmap(originalBitmap);
                    Log.d(TAG, "Imagen original cargada desde: " + originalImagePath);
                } else {
                    Log.w(TAG, "No se pudo cargar imagen desde: " + originalImagePath);
                    ivOriginalProblem.setVisibility(View.GONE);
                }
            } else {
                Log.w(TAG, "Ruta de imagen original no disponible");
                ivOriginalProblem.setVisibility(View.GONE);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error cargando imagen original", e);
            ivOriginalProblem.setVisibility(View.GONE);
        }
    }
    
    /**
     * Renderiza la solución matemática
     */
    private void renderSolution() {
        try {
            Log.d(TAG, "Iniciando renderizado de solución");
            
            // Mostrar indicador de renderizado
            layoutRendering.setVisibility(View.VISIBLE);
            
            // Ejecutar renderizado en hilo de fondo para evitar bloquear UI
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        // Pequeña pausa para mostrar el indicador
                        Thread.sleep(500);
                        
                        // Renderizar en el hilo principal
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    // Renderizar solución
                                    mathRenderer.renderSolutionToLayout(currentSolution, layoutMathSolution);
                                    
                                    // Ocultar indicador de renderizado
                                    layoutRendering.setVisibility(View.GONE);
                                    
                                    // Mostrar información adicional si existe
                                    showAdditionalInfoIfAvailable();
                                    
                                    Log.d(TAG, "Renderizado completado exitosamente");
                                    
                                } catch (Exception e) {
                                    Log.e(TAG, "Error en renderizado UI", e);
                                    showRenderingError();
                                }
                            }
                        });
                        
                    } catch (InterruptedException e) {
                        Log.e(TAG, "Renderizado interrumpido", e);
                        Thread.currentThread().interrupt();
                    } catch (Exception e) {
                        Log.e(TAG, "Error en hilo de renderizado", e);
                        
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                showRenderingError();
                            }
                        });
                    }
                }
            }).start();
            
        } catch (Exception e) {
            Log.e(TAG, "Error iniciando renderizado", e);
            showRenderingError();
        }
    }
    
    /**
     * Muestra información adicional si está disponible
     */
    private void showAdditionalInfoIfAvailable() {
        try {
            if (currentSolution != null && !TextUtils.isEmpty(currentSolution.getExplanation())) {
                // Aquí podrías agregar información adicional sobre el problema
                // Por ejemplo, conceptos utilizados, nivel de dificultad, etc.
                
                // Por ahora, mantener oculto ya que la explicación se muestra en el renderizado principal
                layoutAdditionalInfo.setVisibility(View.GONE);
            }
        } catch (Exception e) {
            Log.e(TAG, "Error mostrando información adicional", e);
        }
    }
    
    /**
     * Muestra error de renderizado
     */
    private void showRenderingError() {
        try {
            layoutRendering.setVisibility(View.GONE);
            
            // Mostrar mensaje de error básico
            layoutMathSolution.removeAllViews();
            
            android.widget.TextView errorView = new android.widget.TextView(this);
            errorView.setText("Error al renderizar la solución matemática.\n\n" +
                              "Solución en texto plano:\n" + 
                              (currentSolution != null ? currentSolution.getFullSolutionText() : "No disponible"));
            errorView.setPadding(16, 16, 16, 16);
            errorView.setTextSize(14);
            
            layoutMathSolution.addView(errorView);
            
            Log.w(TAG, "Mostrado fallback de renderizado");
            
        } catch (Exception e) {
            Log.e(TAG, "Error mostrando error de renderizado", e);
        }
    }
    
    /**
     * Maneja el click del botón "Nuevo Problema"
     */
    private void onNewProblemClicked() {
        try {
            Log.d(TAG, "Navegando a nuevo problema");
            
            // Limpiar recursos actuales
            cleanupResources();
            
            // Regresar a MainActivity
            Intent intent = new Intent(this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish();
            
        } catch (Exception e) {
            Log.e(TAG, "Error navegando a nuevo problema", e);
            Toast.makeText(this, "Error navegando", Toast.LENGTH_SHORT).show();
        }
    }
    
    /**
     * Maneja el click del botón "Compartir Solución"
     */
    private void onShareSolutionClicked() {
        try {
            if (currentSolution == null) {
                Toast.makeText(this, "No hay solución disponible para compartir", Toast.LENGTH_SHORT).show();
                return;
            }
            
            String shareText = prepareShareText();
            
            Intent shareIntent = new Intent(Intent.ACTION_SEND);
            shareIntent.setType("text/plain");
            shareIntent.putExtra(Intent.EXTRA_TEXT, shareText);
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Solución matemática - App IA");
            
            Intent chooser = Intent.createChooser(shareIntent, "Compartir solución");
            if (chooser.resolveActivity(getPackageManager()) != null) {
                startActivity(chooser);
                Log.d(TAG, "Intent de compartir lanzado");
            } else {
                Toast.makeText(this, "No hay aplicaciones disponibles para compartir", Toast.LENGTH_SHORT).show();
            }
            
        } catch (Exception e) {
            Log.e(TAG, "Error compartiendo solución", e);
            Toast.makeText(this, "Error al compartir", Toast.LENGTH_SHORT).show();
        }
    }
    
    /**
     * Prepara el texto para compartir
     */
    private String prepareShareText() {
        StringBuilder shareText = new StringBuilder();
        
        try {
            shareText.append("🧮 SOLUCIÓN MATEMÁTICA - IA\n");
            shareText.append("═══════════════════════════\n\n");
            
            if (!TextUtils.isEmpty(currentSolution.getOriginalProblem())) {
                shareText.append("📝 PROBLEMA:\n");
                shareText.append(currentSolution.getOriginalProblem());
                shareText.append("\n\n");
            }
            
            if (!TextUtils.isEmpty(currentSolution.getSolution())) {
                shareText.append("✅ SOLUCIÓN:\n");
                shareText.append(currentSolution.getSolution());
                shareText.append("\n\n");
            }
            
            if (currentSolution.getSteps() != null && !currentSolution.getSteps().isEmpty()) {
                shareText.append("📋 PASOS:\n");
                for (int i = 0; i < currentSolution.getSteps().size(); i++) {
                    shareText.append("Paso ").append(i + 1).append(": ");
                    shareText.append(currentSolution.getSteps().get(i));
                    shareText.append("\n");
                }
                shareText.append("\n");
            }
            
            if (!TextUtils.isEmpty(currentSolution.getExplanation())) {
                shareText.append("💡 EXPLICACIÓN:\n");
                shareText.append(currentSolution.getExplanation());
                shareText.append("\n\n");
            }
            
            shareText.append("──────────────────────────\n");
            shareText.append("Generado por Solucionador Matemático IA");
            
        } catch (Exception e) {
            Log.e(TAG, "Error preparando texto para compartir", e);
            return "Error preparando solución para compartir";
        }
        
        return shareText.toString();
    }
    
    /**
     * Limpia los recursos utilizados
     */
    private void cleanupResources() {
        try {
            // Limpiar imagen
            if (ivOriginalProblem != null && ivOriginalProblem.getDrawable() != null) {
                ivOriginalProblem.setImageDrawable(null);
            }
            
            // Limpiar layouts
            if (layoutMathSolution != null) {
                layoutMathSolution.removeAllViews();
            }
            
            Log.d(TAG, "Recursos limpiados");
            
        } catch (Exception e) {
            Log.e(TAG, "Error limpiando recursos", e);
        }
    }
    
    /**
     * Muestra error y termina la actividad
     */
    private void showErrorAndFinish(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        Log.e(TAG, "Error crítico: " + message);
        finish();
    }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                onNewProblemClicked();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    
    @Override
    public void onBackPressed() {
        onNewProblemClicked();
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        cleanupResources();
        Log.d(TAG, "SolutionActivity destruida");
    }
}
