#!/bin/bash

# Script de construcción para MathSolver Android App
# Optimizado para Android 4.2.2

echo "🚀 Iniciando construcción de MathSolver App..."

# Verificar que estamos en el directorio correcto
if [ ! -f "build.gradle" ]; then
    echo "❌ Error: Ejecuta este script desde el directorio raíz del proyecto"
    exit 1
fi

# Verificar permisos del gradlew
if [ ! -x "./gradlew" ]; then
    echo "📝 Configurando permisos para gradlew..."
    chmod +x ./gradlew 2>/dev/null || echo "⚠️  No se pudieron cambiar permisos (puede ser normal en algunos entornos)"
fi

# Limpiar construcción anterior
echo "🧹 Limpiando construcción anterior..."
./gradlew clean

# Verificar código
echo "🔍 Verificando código..."
find app/src -name "*.java" -exec echo "Verificando: {}" \;

# Construir APK de debug
echo "🔨 Construyendo APK..."
./gradlew assembleDebug

# Verificar si se generó el APK
APK_PATH="app/build/outputs/apk/debug/app-debug.apk"
if [ -f "$APK_PATH" ]; then
    echo "✅ APK generado exitosamente:"
    echo "📁 Ubicación: $APK_PATH"
    echo "📊 Tamaño: $(du -h $APK_PATH | cut -f1)"
    
    # Crear copia con nombre más descriptivo
    cp "$APK_PATH" "MathSolver-Android-4.2.2.apk"
    echo "📱 Copia creada: MathSolver-Android-4.2.2.apk"
    
    echo ""
    echo "🎉 ¡Construcción completada exitosamente!"
    echo ""
    echo "📋 Próximos pasos:"
    echo "1. Transfiere MathSolver-Android-4.2.2.apk a tu dispositivo Android 4.2.2"
    echo "2. Habilita 'Fuentes desconocidas' en Configuración > Seguridad"
    echo "3. Instala el APK tocando sobre él"
    echo "4. Concede los permisos solicitados"
    echo ""
    echo "📖 Consulta README.md para instrucciones detalladas de uso"
    
else
    echo "❌ Error: No se pudo generar el APK"
    echo "💡 Revisa los errores arriba e intenta lo siguiente:"
    echo "   - Verifica que tienes Android SDK instalado"
    echo "   - Asegúrate de tener Java configurado correctamente"
    echo "   - Intenta ejecutar: ./gradlew assembleDebug --stacktrace"
    exit 1
fi

echo ""
echo "🏁 Script de construcción finalizado."
