# 📱 Guía de Instalación - MathSolver Android 4.2.2

## 🎯 Instalación Rápida

### Para Usuarios (Instalación Directa)

1. **📥 Descarga**
   - Descarga `MathSolver-Android-4.2.2.apk`

2. **🔓 Habilitar Instalación**
   - Ve a `Configuración > Seguridad`
   - Activa `Fuentes desconocidas`

3. **📱 Instalar**
   - Toca el archivo APK descargado
   - Sigue las instrucciones de instalación
   - Concede permisos cuando se soliciten

4. **🚀 ¡Listo!**
   - Abre la app "Solucionador Matemático IA"
   - Toma una foto de un ejercicio matemático
   - ¡Disfruta de las soluciones IA!

---

## 🛠️ Compilación desde Código Fuente

### Requisitos Previos
- **Android SDK**: API Level 17 (Android 4.2.2)
- **Java**: JDK 7 o 8
- **Gradle**: 3.3 (incluido en el proyecto)

### Pasos de Compilación

1. **📂 Preparar Proyecto**
   ```bash
   cd MathSolverApp
   ```

2. **🔨 Compilar**
   ```bash
   # Linux/Mac
   ./build.sh
   
   # O manualmente:
   ./gradlew assembleDebug
   ```

3. **📱 APK Generado**
   - Ubicación: `app/build/outputs/apk/debug/app-debug.apk`
   - O: `MathSolver-Android-4.2.2.apk` (copia conveniente)

---

## 🔧 Configuración Específica Android 4.2.2

### Optimizaciones Aplicadas
- ✅ **API Compatibility**: Solo APIs compatibles con Android 17
- ✅ **Memory Management**: Gestión optimizada para 2GB RAM
- ✅ **WebView Legacy**: Compatible con WebKit 534.30
- ✅ **Performance**: Optimizada para hardware 2013-2014

### Dependencias Optimizadas
- **OkHttp**: 2.7.5 (última versión compatible)
- **Gson**: 2.8.5 (eficiente en memoria)
- **Support Library**: 25.4.0 (Android 4.2.2+)

---

## 🚨 Solución de Problemas

### Error: "No se puede instalar"
**Causa**: Fuentes desconocidas deshabilitadas
**Solución**: 
1. Ve a `Configuración > Seguridad`
2. Activa `Fuentes desconocidas`
3. Intenta instalar nuevamente

### Error: "Aplicación no compatible"
**Causa**: Dispositivo muy antiguo (< Android 4.2.2)
**Solución**: Esta app requiere mínimo Android 4.2.2

### Error: "Falta espacio"
**Causa**: Almacenamiento insuficiente
**Solución**: 
1. Libera al menos 100MB de espacio
2. Desinstala aplicaciones no usadas
3. Limpia cache del sistema

### Error de Compilación: "SDK not found"
**Causa**: Android SDK no configurado
**Solución**:
1. Instala Android Studio o SDK standalone
2. Configura ANDROID_HOME environment variable
3. Asegúrate de tener Android API 17 instalado

---

## 📋 Lista de Verificación Pre-Instalación

### En el Dispositivo Android 4.2.2:
- [ ] Al menos 100MB de espacio libre
- [ ] Fuentes desconocidas habilitadas
- [ ] Cámara funcional
- [ ] Conexión a Internet activa
- [ ] Al menos 1GB RAM disponible

### Para Desarrollo:
- [ ] Android SDK instalado
- [ ] Java JDK 7/8 configurado
- [ ] Android API 17 descargado
- [ ] ANDROID_HOME configurado
- [ ] Gradle 3.3+ disponible

---

## 🎯 Primeros Pasos Post-Instalación

1. **🔓 Permisos**
   - La app solicitará permisos de cámara y almacenamiento
   - Concédelos para funcionamiento completo

2. **🌐 Conectividad**
   - Asegúrate de tener Internet (WiFi o datos móviles)
   - La primera consulta puede tardar más en establecer conexión

3. **📸 Primera Foto**
   - Usa buena iluminación
   - Enfoca bien el problema matemático
   - Incluye todo el ejercicio en la imagen

4. **⏱️ Tiempo de Procesamiento**
   - Primera consulta: 30-60 segundos
   - Consultas posteriores: 15-30 segundos
   - En dispositivos lentos puede tomar más tiempo

---

## 📞 Soporte Técnico

### Información del Sistema
Para reportar problemas, incluye:
- Modelo del dispositivo
- Versión exacta de Android
- Mensaje de error específico
- Pasos para reproducir el problema

### Logs de Debug
Si tienes problemas técnicos:
```bash
# Ver logs durante la instalación
adb logcat | grep MathSolver

# Ver logs de la aplicación
adb logcat | grep com.mathsolver
```

---

**✅ La aplicación está lista para usar una vez completada la instalación**

¡Disfruta resolviendo matemáticas con IA en tu dispositivo Android 4.2.2! 🧮✨
